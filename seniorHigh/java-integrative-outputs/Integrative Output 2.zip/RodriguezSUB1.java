// AUTHOR: Rovic Rodriguez
package Rodriguez_OOP;

public class RodriguezSUB1 extends RodriguezSUPER {
    
    public static void connectivity(){
        System.out.println("Bluetooth enabled!");
    }
    public static void keyboardSize(){
        System.out.println("60% Keyboard");
    }
    public static void keyboardSwitch(){
        System.out.println("Mechanical Switches");
        System.out.println("");
    }
    
}
