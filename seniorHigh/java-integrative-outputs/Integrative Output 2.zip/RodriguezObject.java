// AUTHOR: Rovic Rodriguez 
package Rodriguez_OOP;

public class RodriguezObject {
    
    public static void main(String[] args){
    
    String message = new String("Hello World");
    System.out.println(message);
    String message2 = new String("RodriguezObject.java");
    System.out.println(message2);
    
    }
    
}
