// AUTHOR: Rovic Rodriguez
package Rodriguez_OOP;

public class RodriguezSUPER {
    
    public static void Layout(){
        System.out.println("ANSI Layout");
    }
    public static void Language(){
        System.out.println("English");
    }
}
