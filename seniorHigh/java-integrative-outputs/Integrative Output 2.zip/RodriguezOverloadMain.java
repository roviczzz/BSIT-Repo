//AUTHOR: Rovic Rodriguez
package Rodriguez_OOP;

public class RodriguezOverloadMain {
    
    public static void main(String [] args){
    RodriguezOverloading object1 = new RodriguezOverloading();
    
    object1.print(1);
    object1.print(1.6);
    object1.print("hello world");
    object1.print(1, 5);
    
    }
    
}
