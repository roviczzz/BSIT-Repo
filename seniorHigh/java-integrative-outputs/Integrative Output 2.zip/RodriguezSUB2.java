// AUTHOR: Rovic Rodriguez
package Rodriguez_OOP;

public class RodriguezSUB2 extends RodriguezSUPER {
    
    public static void connectivity(){
        System.out.println("Wired");
    }
    public static void keyboardSize(){
        System.out.println("100% Keyboard");
    }
    public static void keyboardSwitch(){
        System.out.println("Membrane Switches");
        System.out.println("");
    }
    
}
